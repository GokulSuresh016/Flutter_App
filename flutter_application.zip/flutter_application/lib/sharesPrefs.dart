import 'package:shared_preferences/shared_preferences.dart';

Future setStartTime(DateTime startTime)async{
  SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
    sharedPreferences.setString("startTime", startTime.toString());
    print('Successfully set  start time');

}
Future setEndTime(DateTime endTime)async{
  SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
  sharedPreferences.setString("endTime", endTime.toString());
  print('Successfully set  end time');

}

Future onlyOneTimePeriodic()async{
  print('in only one time');
  SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
  sharedPreferences.setBool("oneTimePeriodic", true);

}
Future onlyOneTimePeriodicStop()async{
  SharedPreferences sharedPreferences=await SharedPreferences.getInstance();
  sharedPreferences.setBool("oneTimePeriodic", false);
}