import 'dart:async';

import 'dart:typed_data';
import 'package:flutter/cupertino.dart';
import 'package:flutterapplication/sharesPrefs.dart';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import 'CustomizedNotification.dart';


void main() => runApp(MyApp());


class MyApp extends StatefulWidget {
  @override
  MyStateApp createState() => MyStateApp();


}
class MyStateApp extends State<MyApp>{
  @override

  void initState()
  {
    super.initState();
    var now=DateTime.now();
    var startTime=DateTime(now.year,now.month,now.day,10,00);
    var endTime=DateTime(now.year,now.month,now.day,20,00);
    print('set start and endtime');
    setStartTime(startTime);
    setEndTime(endTime);


  }

  Widget build(BuildContext context) {
    return  new MaterialApp(
      home: Builder(
        builder: (context)=>Scaffold(
          body: Center(
        child:Container(
          child: Column(
            children: <Widget>[
              new Image.asset('images/sanitizer.jpg',
              width: 250,
                  height: 300,),
              new RaisedButton(onPressed: (){
                   Navigator.of(context).push(MaterialPageRoute<Null>(
                  builder: (BuildContext context){
                  return new CustomizedNotification();

              }
             ));},
              child: Icon(
                Icons.add_alarm
              ),
              )
            ],
          ),




       /*  new  RaisedButton(
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute<Null>(
              builder: (BuildContext context){
                return new CustomizedNotification();
              }
            ));
          }
          ),),*/
        ),

            )
      ),
    ));
    }
   

  }
class FlightImageAssset extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
   AssetImage assetImage=AssetImage('assets/sanitizer.jpg');
   Image image=Image(image: assetImage);
   return Container(child: image);
    throw UnimplementedError();
  }



}



