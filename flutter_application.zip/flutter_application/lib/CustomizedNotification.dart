
import 'dart:ui';
import 'package:android_alarm_manager/android_alarm_manager.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutterapplication/notificationHelper.dart';
import 'package:flutterapplication/sharesPrefs.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomizedNotification extends StatefulWidget {
  @override
  _CustomizedNotificationState createState() => _CustomizedNotificationState();
}

class _CustomizedNotificationState extends State<CustomizedNotification> {
  String startTime="";
  String endTime="";
  @override
  void initState(){
    super.initState();
    getTime();
  }
  static periodicCallback(){
    print('in periodic call back');
    NotificationHelper().showNotificationBetweenInterval();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
     child: Container(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: <Widget>[
                      Text('Notification Start From',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 20
                      ),),
                      SizedBox(height: 20,),
                      Text(startTime,style: TextStyle(fontSize: 30),
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  child: Column(
                   children: <Widget>[
                     Text('Notification End At',style: TextStyle(
                       fontSize: 20
                     ),),
                     SizedBox(height: 20,),
                     Text(endTime,style: TextStyle(fontSize: 30),
                     )
                   ],
                  ),
                ),
              ),

              Expanded(
                child: Container(
                  child: Column(
                    children: <Widget>[
                      Container(
                        height: 50,
                       child: RaisedButton(
                        onPressed: () async {
                          WidgetsFlutterBinding.ensureInitialized();
                          await AndroidAlarmManager.initialize();
                          onTimePeridic();

                        },
                         child: Text('START APP',
                         style: TextStyle(
                           fontSize: 20,
                         ),),
                        ),
                      )
                  ],
                ),
                ),
              )
            ],
          ),
        ),
      ),
      ));
  }



  onTimePeridic(){
    SharedPreferences.getInstance().then((value) async{
      var a=value.getBool('oneTimePeriodic')?? false;
      if(!a){
        print('waiting for 60 minutes');
        await AndroidAlarmManager.periodic(Duration(minutes: 60), 0, periodicCallback);
        print('After 60 minutes preiodic call back will exicute');
        onlyOneTimePeriodic();
      }
      else{
        print("cannot run more than once");

      }
    });
  }


  getTime(){
  SharedPreferences.getInstance().then((value){
    var a= value.getString('startTime');
    var b= value.getString('endTime');
    if(a!=null && b!=null){
      setState(() {
        startTime=DateFormat('jm').format(DateTime.parse(a));
        endTime=DateFormat('jm').format(DateTime.parse(b));
      });
    }
  });
  }

}
